# ExampleOrders - Java Version

Proyecto de ejemplo para práctica de pruebas unitarias e integración.

## 1. Requisitos

- JDK 17 o superior
- Maven 3.9+
- IDE recomendado: NetBeans o IntelliJ IDEA

---

## 2. Dependencias (pom.xml)

Agregar en el archivo `pom.xml`:

```xml
<dependencies>
    <!-- JUnit 5 -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.10.0</version>
        <scope>test</scope>
    </dependency>

    <!-- Mockito -->
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <version>5.11.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

---

## 3. Estructura del Proyecto

```
ExampleOrders/
│
├── src/
│   ├── main/java/com/example/orders/
│   │       Order.java
│   │       Product.java
│   │       OrderService.java
│   │       IOrderRepository.java
│   │       OrderRepository.java
│   │
│   └── test/java/com/example/orders/
│           OrderServiceTest.java
│           ProductTest.java
```

---

## 4. Crear un Test

Ejemplo básico:

```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void shouldCalculateSubtotal() {
        Product product = new Product("Laptop", 1000, 2);

        double subtotal = product.getSubtotal();

        assertEquals(2000, subtotal);
    }
}
```

---

## 5. Asserts principales

```java
assertEquals(expected, actual);
assertNotEquals(unexpected, actual);
assertTrue(condition);
assertFalse(condition);
assertNull(value);
assertNotNull(value);
assertThrows(Exception.class, () -> method());
```

---

## 6. Crear un Mock con Mockito

```java
import static org.mockito.Mockito.*;

@Test
void shouldSaveOrder() {

    IOrderRepository repo = mock(IOrderRepository.class);
    when(repo.save(any())).thenReturn(1);

    OrderService service = new OrderService(repo);
    Order order = new Order();

    service.processOrder(order);

    verify(repo, times(1)).save(order);
}
```

Simular excepción:

```java
when(repo.save(any())).thenThrow(new RuntimeException());
```

---
