/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author brianda
 */
public class Order {
    private String id;
    private List<OrderItem> items = new ArrayList<>();
    private boolean paid;

    public Order(String id) {
        if (id == null || id.isBlank())
            throw new IllegalArgumentException("Id requerido");

        this.id = id;
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    public double calculateTotal() {
        return items.stream()
                .mapToDouble(OrderItem::getSubtotal)
                .sum();
    }

    public void markAsPaid() {
        paid = true;
    }

    public boolean isPaid() { return paid; }
    public List<OrderItem> getItems() { return items; }
}
