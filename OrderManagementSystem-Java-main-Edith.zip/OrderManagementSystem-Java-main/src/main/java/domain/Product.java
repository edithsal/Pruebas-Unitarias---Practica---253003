/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;

/**
 *
 * @author brianda
 */
public class Product {
    private String id;
    private String name;
    private double price;
    private int stock;

    public Product(String id, String name, double price, int stock) {

        if (id == null || id.isBlank())
            throw new IllegalArgumentException("Id requerido");

        if (price <= 0)
            throw new IllegalArgumentException("Precio inválido");

        if (stock < 0)
            throw new IllegalArgumentException("Stock inválido");

        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public void reduceStock(int quantity) {
        if (quantity <= 0)
            throw new IllegalArgumentException("Cantidad inválida");

        if (quantity > stock)
            throw new IllegalStateException("Stock insuficiente");

        stock -= quantity;
    }

    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public String getId() { return id; }
}
