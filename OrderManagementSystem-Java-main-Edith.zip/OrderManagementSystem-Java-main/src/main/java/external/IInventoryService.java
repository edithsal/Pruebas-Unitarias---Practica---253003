/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package external;

import domain.Product;

/**
 *
 * @author brianda
 */
public interface IInventoryService {
    void updateStock(Product product, int quantity);
}