/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import domain.Order;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author brianda
 */
public class InMemoryOrderRepository implements IOrderRepository  {
    
     private List<Order> database = new ArrayList<>();

    @Override
    public void save(Order order) {
        database.add(order);
    }

    public int count() {
        return database.size();
    }
}
