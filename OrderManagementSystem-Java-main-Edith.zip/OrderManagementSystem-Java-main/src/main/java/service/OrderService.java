/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import domain.Order;
import domain.OrderItem;
import external.IInventoryService;
import external.IPaymentGateway;
import repository.IOrderRepository;

/**
 *
 * @author brianda
 */
public class OrderService {
    private IOrderRepository repository;
    private IPaymentGateway paymentGateway;
    private IInventoryService inventoryService;
    private DiscountService discountService;
    private TaxService taxService;

    public OrderService(IOrderRepository repository,
                        IPaymentGateway paymentGateway,
                        IInventoryService inventoryService,
                        DiscountService discountService,
                        TaxService taxService) {

        this.repository = repository;
        this.paymentGateway = paymentGateway;
        this.inventoryService = inventoryService;
        this.discountService = discountService;
        this.taxService = taxService;
    }

    public boolean checkout(Order order) {

        if (order.getItems().isEmpty())
            throw new IllegalStateException("Orden vacía");

        double total = order.calculateTotal();

        total = discountService.applyDiscount(total);
        total = taxService.applyTax(total);

        boolean paymentSuccess = paymentGateway.processPayment(total);

        if (!paymentSuccess)
            return false;

        for (OrderItem item : order.getItems()) {
            inventoryService.updateStock(
                    item.getProduct(),
                    item.getQuantity());
        }

        order.markAsPaid();
        repository.save(order);

        return true;
    }
}
