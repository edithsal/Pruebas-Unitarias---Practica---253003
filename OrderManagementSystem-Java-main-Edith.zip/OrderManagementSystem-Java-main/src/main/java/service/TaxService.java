/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author brianda
 */
public class TaxService {
        public double applyTax(double amount) {
        return amount * 1.16;
    }
}
